package com.project.vo;

import java.util.ArrayList;

public class CommentsList {
	ArrayList<CommentsVO> list = new ArrayList<CommentsVO>();

	public ArrayList<CommentsVO> getList() {
		return list;
	}

	public void setList(ArrayList<CommentsVO> list) {
		this.list = list;
	}
	
}
