package com.project.vo;

import java.util.ArrayList;

public class UserList {
	ArrayList<UserVO> list = new ArrayList<UserVO>();

	public ArrayList<UserVO> getList() {
		return list;
	}

	public void setList(ArrayList<UserVO> list) {
		this.list = list;
	}
	
}
